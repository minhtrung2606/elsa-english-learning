export const QuestionCategory = {
  SingleOption: 'single',
};
