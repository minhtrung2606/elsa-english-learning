export type PaginationOption = {
  page: number;
  itemsPerPage: number;
}
